#& "C:\Program Files\Python312\python.exe" -m pip install numpy matplotlib scikit-fuzzy python-constraint networkx


import math

def print_b(b): [print(" | ".join(r)) for r in b]; print()
def mv_left(b): return any(c==' ' for r in b for c in r)
def val(b):
    for i in range(3):
        if b[i][0]==b[i][1]==b[i][2]!=" ": return 10 if b[i][0]=="X" else -10
        if b[0][i]==b[1][i]==b[2][i]!=" ": return 10 if b[0][i]=="X" else -10
    if b[0][0]==b[1][1]==b[2][2]!=" ": return 10 if b[0][0]=="X" else -10
    if b[0][2]==b[1][1]==b[2][0]!=" ": return 10 if b[0][2]=="X" else -10
    return 0
def mini(b,ismax):
    s=val(b)
    if s or not mv_left(b): return s
    best=-math.inf if ismax else math.inf
    for i in range(3):
        for j in range(3):
            if b[i][j]==' ':
                b[i][j]='X' if ismax else 'O'
                best=max(best,mini(b,not ismax)) if ismax else min(best,mini(b,not ismax))
                b[i][j]=' '
    return best
def best_move(b):
    best=-math.inf; move=(-1,-1)
    for i in range(3):
        for j in range(3):
            if b[i][j]==' ':
                b[i][j]='X'
                valm=mini(b,False)
                b[i][j]=' '
                if valm>best: best,move=valm,(i,j)
    return move


print("Enter board rows (use X,O,space for empty):")
board=[]
for i in range(3):
    row=input(f"Row {i+1}: ").strip().split()
    while len(row)<3: row.append(' ')   
    board.append(row[:3])              

print_b(board)
m=best_move(board)
print("Best move for AI (X): Row =",m[0],", Col =",m[1])


##Enter board rows (use X,O,space for empty):
#Row 1: X O X 
#Row 2: O O
#Row 3:     X
# ------------------------------------------------------
# EXPLANATION OF THE CODE (TIC TAC TOE USING MINIMAX)
# ------------------------------------------------------

# 📘 AIM:
# This program uses the **Minimax algorithm** to find the 
# best possible move for an AI player ('X') in a Tic Tac Toe game.

# The AI assumes that the opponent ('O') also plays optimally
# and calculates the best move to either win or avoid losing.

# ------------------------------------------------------
# 🧩 CODE EXPLANATION (LINE BY LINE)
# ------------------------------------------------------

# import math
# → Imports the math library to use infinity values 
#   for comparison in the Minimax algorithm.

# ------------------------------------------------------
# FUNCTION: print_b(b)
# ------------------------------------------------------
# → Prints the Tic Tac Toe board in a readable format.
# Example Output:
# X | O | X
# O |   |  
#   |   | X
# def print_b(b): [print(" | ".join(r)) for r in b]; print()

# ------------------------------------------------------
# FUNCTION: mv_left(b)
# ------------------------------------------------------
# → Checks if there are any empty spaces left on the board.
# Returns True if at least one cell is empty, else False.
# def mv_left(b): return any(c==' ' for r in b for c in r)

# ------------------------------------------------------
# FUNCTION: val(b)
# ------------------------------------------------------
# → Evaluates the board and returns:
#    +10 if 'X' (AI) has won
#    -10 if 'O' (opponent) has won
#     0  if no winner yet
# → It checks all rows, columns, and diagonals.
# def val(b):
#     for i in range(3):
#         if b[i][0]==b[i][1]==b[i][2]!=" ": return 10 if b[i][0]=="X" else -10
#         if b[0][i]==b[1][i]==b[2][i]!=" ": return 10 if b[0][i]=="X" else -10
#     if b[0][0]==b[1][1]==b[2][2]!=" ": return 10 if b[0][0]=="X" else -10
#     if b[0][2]==b[1][1]==b[2][0]!=" ": return 10 if b[0][2]=="X" else -10
#     return 0

# ------------------------------------------------------
# FUNCTION: mini(b, ismax)
# ------------------------------------------------------
# → This is the recursive **Minimax function**.
# → It simulates all possible future moves to find the
#   optimal one for AI ('X') and worst for opponent ('O').
# Parameters:
#   b     : Current board state
#   ismax : True if AI's turn, False if opponent's turn

# Working:
# - If a win/loss is found, it returns the score (+10 or -10)
# - If the board is full (no moves left), it returns 0 (draw)
# - Otherwise, it tries all possible moves recursively and
#   chooses the best score for AI or the worst for the opponent.
# def mini(b,ismax):
#     s=val(b)
#     if s or not mv_left(b): return s
#     best=-math.inf if ismax else math.inf
#     for i in range(3):
#         for j in range(3):
#             if b[i][j]==' ':
#                 b[i][j]='X' if ismax else 'O'
#                 best=max(best,mini(b,not ismax)) if ismax else min(best,mini(b,not ismax))
#                 b[i][j]=' '
#     return best

# ------------------------------------------------------
# FUNCTION: best_move(b)
# ------------------------------------------------------
# → Finds the best move for AI ('X') using the minimax function.
# → It checks every empty position on the board, simulates a move,
#   evaluates it using the minimax function, and keeps track of 
#   the move with the highest value.
# def best_move(b):
#     best=-math.inf; move=(-1,-1)
#     for i in range(3):
#         for j in range(3):
#             if b[i][j]==' ':
#                 b[i][j]='X'
#                 valm=mini(b,False)
#                 b[i][j]=' '
#                 if valm>best: best,move=valm,(i,j)
#     return move

# ------------------------------------------------------
# USER INPUT AND EXECUTION
# ------------------------------------------------------
# → The user enters the current board state row by row.
#   'X' = AI move
#   'O' = opponent move
#   ' ' = empty space
# print("Enter board rows (use X,O,space for empty):")
# board=[]
# for i in range(3):
#     row=input(f"Row {i+1}: ").strip().split()
#     while len(row)<3: row.append(' ')   
    # board.append(row[:3])              

# Print the entered board
# print_b(board)

# Find and display the best move for the AI
# m=best_move(board)
# print("Best move for AI (X): Row =",m[0],", Col =",m[1])

# ------------------------------------------------------
# 🧮 SAMPLE INPUT / OUTPUT
# ------------------------------------------------------

# Input:
# Enter board rows (use X,O,space for empty):
# Row 1: X O X
# Row 2: O O
# Row 3:     X

# Output:
# X | O | X
# O | O |  
#   |   | X
#
# Best move for AI (X): Row = 2 , Col = 1

# ------------------------------------------------------
# 🧠 SIMPLE UNDERSTANDING:
# ------------------------------------------------------
# The program simulates all possible game outcomes using recursion
# and chooses the move that maximizes AI's chances of winning.

# It assumes that both players (AI and opponent) play optimally.

# ------------------------------------------------------
# 🌍 REAL-TIME USES:
# ------------------------------------------------------
# - Used in AI game development for decision-making.
# - Forms the base of many game algorithms like Chess, Checkers, etc.
# - Helps computers learn how to play turn-based games efficiently.

# ------------------------------------------------------
# 🕒 TIME COMPLEXITY:
# O(b^m)
# where:
#   b = branching factor (number of possible moves)
#   m = depth of the game tree
# For Tic Tac Toe, this is small enough to compute easily.

# 💾 SPACE COMPLEXITY:
# O(m) — due to recursive calls (depth of recursion)
# ------------------------------------------------------
